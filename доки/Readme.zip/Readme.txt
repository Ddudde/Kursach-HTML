Пока что готов лишь сайт, но он без оптимизации и ресайза.

Ссылка на github: https://github.com/Ddudde/Kursach-HTML
Ссылка на сайт: https://cursach228.000webhostapp.com

